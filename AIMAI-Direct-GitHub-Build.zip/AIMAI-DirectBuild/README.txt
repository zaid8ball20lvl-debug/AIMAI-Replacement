AIM AI Replacement - Direct GitHub Actions build

This is a clean replacement shell. It does not contain or bypass any original key/license verification system.
Build workflow: .github/workflows/build-apk.yml
APK output: app/build/outputs/apk/debug/app-debug.apk
Expected app label: AIM AI Replacement
Expected package: com.aimai.replacement.direct
